package com.bank.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.dto.Blog;

@RestController
@CrossOrigin(origins="*")
@RequestMapping(value= "/bloggersPlace")
public class BlogController {
	
	//creating blog
	@PostMapping(value ="/blog", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Blog> createNewBlog(@RequestBody Blog blog) {
		
			blogId= ++ blogId;
		blog.setId(blogId);
		blogs.add(blog);
		if(blog.getTitle() !=null && !blog.getTitle().isEmpty() && blog.getContent()!=null && !blog.getContent().isEmpty()) {
		return new ResponseEntity(blog, HttpStatus.CREATED);
		}else
		return new ResponseEntity(HttpStatus.BAD_REQUEST);
	}
	
	
	//getting  blog by Id
	@GetMapping(value="/blog/{id}" ,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Blog> getBlogById(@PathVariable("id") int blogId){
	
		for(Blog blog:blogs) {
			if(blog.getId()==blogId)
				return new ResponseEntity(blog, HttpStatus.OK);
		}
		return new ResponseEntity(HttpStatus.NOT_FOUND);
		
		
	}
	
	
	@DeleteMapping(value="/blog/{id}" ,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Blog> deleteBlogById(@PathVariable("id") int id){
	
		for(Blog blog:blogs) {
			if(blog.getId()==id) {
				blogs.remove(blog);
			 return new ResponseEntity(true, HttpStatus.OK);
			}
		}
		 return new ResponseEntity(false, HttpStatus.NOT_FOUND);
	}
	
	
	@PutMapping(value="/blog/{id}" ,produces=MediaType.APPLICATION_JSON_VALUE)
	public  ResponseEntity<Blog> updateBlogById(@PathVariable("id") int id,@RequestBody Blog updatedBlog){
	
		for(Blog blog:blogs) {
			if(blog.getId()==id) {
				blog.setTitle(updatedBlog.getTitle());
			blog.setContent(updatedBlog.getContent());
			return new ResponseEntity(blog, HttpStatus.OK);
			}
		}
		return new ResponseEntity(HttpStatus.NOT_FOUND);
		
		
	}
	
	
	@PostMapping(value ="/blog/comment", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Blog> postBlogComment(@RequestBody Blog reqblog) {
		
		for(Blog blog:blogs) {
			if(blog.getId()==reqblog.getId()) {
			blog.setComment(reqblog.getComment());
			return new ResponseEntity(blog, HttpStatus.OK);
			}
		}
		
		return new ResponseEntity(HttpStatus.NOT_FOUND);	
	}
	
static List<Blog> blogs = new ArrayList<>();
	
	static int blogId=0;

}
	
