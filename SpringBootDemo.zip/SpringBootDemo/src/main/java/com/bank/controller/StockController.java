package com.bank.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.dto.Stock;

@RestController
@CrossOrigin(origins="*")
@RequestMapping(value= "/mymarketplace")
public class StockController {
	
	
	//getting All Stocks
	@GetMapping(value="/stock" ,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Stock> getAllStocks(){
		return stocks;
		
	}
	
	/*//getting All Stocks
		@GetMapping(value="/stock/{id}" ,produces=MediaType.APPLICATION_JSON_VALUE)
		public Stock getStockById(@PathVariable("id") int stockId){
		
			for(Stock stock:stocks) {
				if(stock.getId()==stockId)
					return stock;
			}
			return null;
			
			
		}*/
		
		
		//getting All Stocks
				@GetMapping(value="/stock/{id}" ,produces=MediaType.APPLICATION_JSON_VALUE)
				public Stock getStockById(@RequestBody int stockId){
				
					for(Stock stock:stocks) {
						if(stock.getId()==stockId)
							return stock;
					}
					return null;
					
					
				}
		
				@DeleteMapping(value="/stock/{stockId}" ,produces=MediaType.APPLICATION_JSON_VALUE)
				public List<Stock> deleteStockById(@PathVariable int stockId){
				
					for(Stock stock:stocks) {
						if(stock.getId()==stockId)
							stocks.remove(stock);
						
					}
					return stocks;	
				}
				
				
				@PutMapping(value="/stock/{stockId}" ,produces=MediaType.APPLICATION_JSON_VALUE)
				public List<Stock> updateStockById(@PathVariable int stockId,@RequestBody Stock updatestock){
				
					for(Stock stock:stocks) {
						if(stock.getId()==updatestock.getId())
							stock.setMarketName(updatestock.getMarketName());
						stock.setName(updatestock.getName());
						stock.setPrice(updatestock.getPrice());
						
					}
					return stocks;	
				}
		
	
				@DeleteMapping(value="/stock" ,produces=MediaType.APPLICATION_JSON_VALUE)
				public List<Stock> deleteAllStocks(){
				
					stocks.removeAll(stocks);
					return stocks;	
				}
	//create stocks
	@PostMapping(value ="/stock", consumes= {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE}, produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Stock> creatNewStock(@RequestBody Stock stock,@RequestHeader("auth-token") String authToken) {
		if(authToken.equalsIgnoreCase("Mb50026")) {
		lastStock= ++ lastStock;
		stock.setId(lastStock);
		stocks.add(stock);
		return new ResponseEntity(stock, HttpStatus.OK);
		}
		return new ResponseEntity(HttpStatus.BAD_REQUEST);
		
	}
	
	static List<Stock> stocks = new ArrayList<>();
	
	static int lastStock=0;

}
