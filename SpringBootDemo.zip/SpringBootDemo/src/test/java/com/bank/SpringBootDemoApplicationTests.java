package com.bank;

/*@SpringBootTest
class SpringBootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}*/
