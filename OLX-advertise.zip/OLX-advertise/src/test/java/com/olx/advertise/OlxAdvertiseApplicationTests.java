package com.olx.advertise;

/*@SpringBootTest
class OlxAdvertiseApplicationTests {

	@Test
	void contextLoads() {
	}
*/
//}
