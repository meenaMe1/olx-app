package com.olx.advertise.delegate;

public interface UserServiceDelegate {
	
	boolean isLoggedInUser(String authToken);


}
