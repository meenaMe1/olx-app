package com.olx.advertise.service;

import java.util.List;

import com.olx.advertise.dto.Advertise;

public interface AdvertiseService {
	
	public Advertise createAdvertise(String authToken, Advertise advertise);
	
	public Advertise updateAvertisement(String authToken, Advertise advertise);
		
	public List<Advertise> getAllUserAdvertisement( String authToken);
	
	public Advertise getUserAdvertisementById(String authToken , int postId);
				
	public boolean deleteAdvertisementById(String authToken , int postId);
	
	public List<Advertise> getUserAdvertisementByFilter(String criteria);
	
	public List<Advertise> getUserAdvertisementBySearchtext(String searchText);
	
	public Advertise getAdvertisementById(String authToken , int postId);
	
	//boolean isLoggedInUser(String authToken);


}
