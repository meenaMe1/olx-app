package com.spring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class MyApplicationBeanPostProcessor implements BeanPostProcessor{


	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("\tpostProcessAfterInitialization: " + beanName);
		return bean;
	}

	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("\tpostProcessBeforeInitialization: " + beanName);
		if(bean instanceof com.spring.LifeCycleBean) {
			com.spring.LifeCycleBean lifecycle = (com.spring.LifeCycleBean)bean;
			lifecycle.setTitle("New title by post processor");
		}
		return bean;
	}

}
