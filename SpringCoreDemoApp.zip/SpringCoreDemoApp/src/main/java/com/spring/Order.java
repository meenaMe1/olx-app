package com.spring;

import java.awt.geom.QuadCurve2D;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Order implements BeanNameAware {
	
	
	@Autowired
	@Qualifier(value="item_1")
	private Item item;
	
	private String title;


	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void initMyOrder() {
		System.out.println("Inside initMyOrder");
	}
	
	public void destroyMyBean() {
		System.out.println("Inside destroyMyBean");
	}
	
	public Order(Item item, String title) {
		super();
		this.item = item;
		this.title = title;
	}

	@Override
	public String toString() {
		return "Order [item=" + item + ", title=" + title + ", getTitle()=" + getTitle() + ", getItem()=" + getItem()
				
				+ "]";
	}

	public Order(Item item) {
		super();
		this.item = item;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Order() {
		System.out.println("Inside constructor order");
	}

	public void setBeanName(String name) {
		// TODO Auto-generated method stub
		System.out.println("Bean Name: " +name);

	}
	

}
