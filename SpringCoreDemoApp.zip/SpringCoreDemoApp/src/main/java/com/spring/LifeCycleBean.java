package com.spring;

import javax.security.auth.Destroyable;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.InitializingBean;

public class LifeCycleBean implements BeanNameAware, InitializingBean, Destroyable{

	private String title;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
		
		System.out.println("Inside setter");
	}

	public LifeCycleBean(String title) {
		super();
		this.title = title;
		System.out.println("Inside parameters constructor");
	}
	
	public LifeCycleBean() {
		System.out.println("Inside default constrctor");
	}

	@Override
	public String toString() {
		return "LifeCycleBean [title=" + title + ", getTitle()=" + getTitle() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	public void setBeanName(String name) {
		System.out.println("Inside base name :"+ name);
		
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println("After property set");
		
	}
	
	public void myInit() {
		System.out.println("Inside myInit");
	}
	
	public void myDestroy() {
		System.out.println("Inside myDestroy");
	}
	
	public void destroy() {
		System.out.println("Inside destroy");
	}
	

}
