package com.spring;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
     //  AbstractApplicationContext iocContainer = new ClassPathXmlApplicationContext("bean.xml");
       
       AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
       
      Contact con= context.getBean(Contact.class);
      System.out.println(con.getName());
       
    /*  Item item=(Item)iocContainer.getBean("item");
       
      System.out.println(item);
       
       Order order=(Order)iocContainer.getBean("order_1");
       System.out.println(order);*/
       
       /*Order order=(Order)iocContainer.getBean("order_1");
       Order order2=(Order)iocContainer.getBean("order_2");
      int totalPrice =Integer.parseInt(order.getItem().getPrice())+Integer.parseInt(order2.getItem().getPrice());
       
       System.out.println(totalPrice);*/
       
     /* Map<String,Order> mapOfOrder =iocContainer.getBeansOfType(com.spring.Order.class);
      
      Set<String> keyset=mapOfOrder.keySet();
      Iterator<String> itr = keyset.iterator();
      double totalOrder= 0.0;
      while(itr.hasNext()) {
    	  String beanId=itr.next();
    	  Order order = mapOfOrder.get(beanId);
    	  totalOrder=totalOrder+(order.getItem().getPrice());
      }
       System.out.println(totalOrder);*/
     /* Order order=(Order)iocContainer.getBean("order_1");
//       Order order2=(Order)iocContainer.getBean("order_1");
      System.out.println(order);*/
       
     /*  LifeCycleBean lifecycle= (LifeCycleBean)iocContainer.getBean("LifeCycleBean");
       System.out.println(lifecycle);
       */
       
       //iocContainer.registerShutdownHook();
    }
}
