package com.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class AppConfig {

	
	@Bean
	public Contact getContact() {
		return new Contact("TOM");
	}
	

	@Bean
	@Primary
	public Contact getContact2() {
		return new Contact("Jerry");
	}
	
}
class Contact{
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Contact(String name) {
		super();
		this.name = name;
	}
	
	
}