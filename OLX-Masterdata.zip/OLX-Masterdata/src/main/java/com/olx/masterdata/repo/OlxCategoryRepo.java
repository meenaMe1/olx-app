package com.olx.masterdata.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olx.masterdata.entity.CategoryEntity;

public interface OlxCategoryRepo extends JpaRepository<CategoryEntity, Integer>{

}
