package com.olx.masterdata.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olx.masterdata.dto.Category;
import com.olx.masterdata.dto.Status;
import com.olx.materdata.service.MasterDataService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin(origins="*")
public class MasterDataController {
	
	@Autowired
	MasterDataService masterDataService;
	
	@GetMapping(value ="/category", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="fetch all advertisement categories" , notes="This service fetch all advertisement categories")
	public ResponseEntity<Map<String, Object>> getAllAdvertiseCategory() {
		Map<String, Object> allcategory = new HashMap<>();
		List<Category> categoryList=new ArrayList<Category>();
		/*Catergory category = new Catergory(1,"Electronics");
		Catergory category1 = new Catergory(2,"Furniture");
		categoryList.add(category);	*/
		categoryList=masterDataService.getAllAdvertiseCategory();
		allcategory.put("categories", categoryList);
	return new ResponseEntity(allcategory,HttpStatus.OK);
	}
	
	
	
	@GetMapping(value ="/status", produces={MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	@ApiOperation(value="fetch all advertisement status" , notes="This service fetch all advertisement status")
	public ResponseEntity<List<Status>> getAllAdvertiseStatus() {
		List<Status> statusList=new ArrayList<Status>();
		statusList = masterDataService.getAllAdvertiseStatus();
	return new ResponseEntity(statusList,HttpStatus.OK);
	}

}
