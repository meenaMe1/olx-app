package com.olx.masterdata.dto;

import org.springframework.stereotype.Component;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@ApiModel(value ="Category model holds information about a specific category of products")
@Component
public class Category {
	
	private int id;
	@ApiModelProperty(value="Product Category")
	private String category;

}
