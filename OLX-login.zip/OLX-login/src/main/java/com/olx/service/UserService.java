package com.olx.service;

import org.springframework.security.core.userdetails.UserDetails;

import com.olx.dto.User;

public interface UserService {
	
	public String authenticateUser(User login);
	
	public User getUserRegistration(User login);
	
	public boolean userLogout(String authToken);
	
	public User getUserDetails(String authToken);

	public UserDetails loadUserByUsername(String userName);


}
