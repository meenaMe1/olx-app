package com.olx.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.olx.entity.UserEntity;

public interface OlxLoginRepo extends JpaRepository<UserEntity, Integer>{
	
	
	@Query( value = "SELECT * FROM user u WHERE u.userName = ?1", 
			  nativeQuery = true)
	public List<UserEntity> findByUserName(String userName);

}
