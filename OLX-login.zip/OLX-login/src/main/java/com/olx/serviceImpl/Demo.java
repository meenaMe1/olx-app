package com.olx.serviceImpl;

public class Demo {

	public static void main(String[] args) {
		/*
		 * You are given an input list of strings, ordered by ascending length.
		 * 
		 * 
		 * 
		 * Write a function that returns True if, for each pair of consecutive strings,
		 * the second string can be formed from the first by adding a single letter
		 * either at the beginning or end.
		 * 
		 * 
		 * 
		 * Examples canBuild(["a", "at", "ate", "late", "plate", "plates"]) ➞ True
		 * 
		 * 
		 * 
		 * canBuild(["a", "at", "ate", "late", "plate", "plater", "platter"]) ➞ False
		 * 
		 * 
		 * 
		 * canBuild(["it", "bit", "bite", "biters"]) ➞ False
		 * 
		 * 
		 * 
		 * 
		 * canBuild(["mean", "meany"]) ➞ True
		 * 
		 * 
		 * 
		 * Notes: Return False if a word is NOT formed by adding only one letter. Return
		 * False if the letter is added to the middle of the previous word. Letters in
		 * tests will all be lower case.
		 */

		String [] arr = {"it", "bit", "bite", "biters"};

		boolean result = canBuild(arr);

		System.out.println(result);

	}
	
	/*
	 * public static boolean canBuild(String arr []) { boolean result = false;
	 * 
	 * for(int i=0; i < arr.length-2 ; i++) {
	 * 
	 * System.out.println("First index sub String : "
	 * +arr[i+1].substring(0,arr[i+1].length()-1));
	 * 
	 * System.out.println("last index sub string : "+arr[i+1].substring(arr[i+1].
	 * length()-1));
	 * 
	 * if(arr[i+1].substring(0,arr[i+1].length()-1).equals(arr[i]) ||
	 * arr[i+1].substring(arr[i+1].length()-1).equals(arr[i])) {
	 * 
	 * result= true; }else { result = false; break;
	 * 
	 * }
	 * 
	 * 
	 * }
	 * 
	 * return result; }
	 * 
	 * 
	 */
	
	public static boolean canBuild(String arr []) {
		boolean result = false;

		for(int i=0; i < arr.length-1 ; i++) {
			
			System.out.println("First index sub String : " +arr[i+1].substring(0,arr[i+1].length()-1));
			
			System.out.println("last index sub string : "+arr[i+1].substring(1));

			if(arr[i+1].substring(0,arr[i+1].length()-1).equals(arr[i]) || arr[i+1].substring(1).equals(arr[i])) {

				result= true;
			}else {
				result = false;
				break;

			}
			
			
		}

		return result;
	}
}
