package com.olx.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.olx.dto.User;
import com.olx.entity.UserEntity;
import com.olx.repo.OlxLoginRepo;
import com.olx.service.UserService;

@Service
public class UserServiceImpl implements UserService, UserDetailsService{

	@Autowired
	User user;

	@Autowired
	OlxLoginRepo olxRepo;
	
	@Override
	public String authenticateUser(User login) {
		
		return null;
	}

	@Override
	public User getUserRegistration(User login) {
		UserEntity userEntity = new UserEntity(user.getId(), user.getFirstName(), user.getLastName(), user.getUserName(), user.getPassword(), user.getEmail(), user.getPhone());
		userEntity = olxRepo.save(userEntity);
		login =new User(userEntity.getId(), userEntity.getFirstName(), userEntity.getLastName(), userEntity.getUserName(), userEntity.getPassword(), userEntity.getEmail(), userEntity.getPhone());
		return login;
		
	}

	@Override
	public boolean userLogout(String authToken) {
	
		return false;
	}

	@Override
	public User getUserDetails(String authToken) {
		UserEntity userEntity = new UserEntity(user.getId(), user.getFirstName(), user.getLastName(), user.getUserName(), user.getPassword(), user.getEmail(), user.getPhone());
		userEntity = olxRepo.save(userEntity);
		User login =new User(userEntity.getId(), userEntity.getFirstName(), userEntity.getLastName(), userEntity.getUserName(), userEntity.getPassword(), userEntity.getEmail(), userEntity.getPhone());
		return login;
	}
	
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		List<UserEntity> userList = olxRepo.findByUserName(username);
		if(userList==null && userList.size()==0) {
			throw new UsernameNotFoundException(username);
		}else {
		UserEntity userentity = userList.get(0);
		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority(userentity.getRole()));
		org.springframework.security.core.userdetails.User user = new org.springframework.security.core.userdetails.User(userentity.getUserName(), userentity.getPassword(),authorities);
		return user;
		}
	}


	/*
	 * Given array of integers X and a target integer Y, find the indices of number
	 * such that the numbers add up to target. nums = [2, 7,11,15], target = 9 Ans -
	 * [0,1], 2(index 0) + 7(index 1) = 9
	 */
	
	public static void main(String args []) {
		List<Integer> list = new ArrayList<Integer>();
		
		list.add(2);
		list.add(7);
		list.add(11);
		list.add(15);
		int sum =14;
		int numSum=0;
		
		
		
		for(int i=0; i< list.size()-1;i++) {
			int index1=0;
			int index2 =0;
			
			for(int j=i+1; j< list.size();j++) {
			
				numSum=list.get(i)+list.get(j);
				
				if(numSum==sum) {
					index1=i;
					index2=j;
					System.out.println(index1 + "  "  +index2);
				}
			}
			
		}
		
		
	}
	
	
	
	
	
	
	
}
