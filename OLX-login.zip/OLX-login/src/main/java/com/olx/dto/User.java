package com.olx.dto;

import org.springframework.stereotype.Component;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
@ApiModel(value ="User model holds information about a user details")
@Component
public class User {
	
	private int id;
	@ApiModelProperty(value="First Name")
	private String firstName;
	private String lastName;
	private String userName;
	private String password;
	private String email;
	private int phone;
	private String role;
  
	public User(String userName, String password, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	public User(int id, String firstName, String lastName, String userName, String password, String email, int phone) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.phone = phone;
	}
	/*
	 * public User(String userName, String password, List<GrantedAuthority>
	 * authorities) { this.userName = userName; this.password = password;
	 * //this.authorities=authorities; }
	 */ 


}
