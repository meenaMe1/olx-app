function showAlert() {
	alert('Show alert called');
}