package com.olx.service;

import java.util.List;
import java.util.Map;

public interface CategoryServiceDelegate {
	public List<Map> getAllCategories();
}
